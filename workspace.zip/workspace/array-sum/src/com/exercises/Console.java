package com.exercises;

import java.util.Scanner;

public class Console {

	public static int read(String string) {
		System.out.println(string);
		Scanner scanner = new Scanner(System. in);
		int i = scanner.nextInt();
		scanner.close();
		return i;
	}

	public static void print(String msg) {
		System.out.print(msg);
	}

}
