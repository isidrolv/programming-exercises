/**
 * 
 */
package com.exercises;

/**
 * @author Eurouser
 *
 */
public class ArraySumProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Console.print("Calculate the sum of an array of numbers");
		ArrayOfNumbers array = InputReader.read();
		int sum = ArraySumarizer.sum(array); 
		Console.print(String.format("The result is %s", sum));
	}

}
