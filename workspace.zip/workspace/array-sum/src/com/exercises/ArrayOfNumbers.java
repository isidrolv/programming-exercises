package com.exercises;

public class ArrayOfNumbers {

	private int[] data;
	private int top;
	
	public ArrayOfNumbers() {
		data = new int[100]; 
		top  = -1;
	}
	
	public void addNumber(int number) {
		top++;
		data[top] = number; 
	}
	
	public void removeNumber(int index) {
		for(int i=index; i<top; i++) {
			data[i] = data[i+1];
		}
		top--;
	}
	
	public int[] getData() {
		return data;
	}
}
