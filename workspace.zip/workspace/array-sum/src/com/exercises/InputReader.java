package com.exercises;

public class InputReader {

	public static ArrayOfNumbers read() {
		ArrayOfNumbers array = new ArrayOfNumbers();
		int number = Console.read("Enter an integer number:");
		while (number != -100) {
			array.addNumber(number);
			number = Console.read("Enter an integer number:");
		}
		return array;
	}

}
