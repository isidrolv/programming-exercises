package com.exercises;

public class ArraySumarizer {

	public static int sum(ArrayOfNumbers array) {
		int sum = 0;
		for(int i=0; i<array.getData().length; i++) {
			int value = array.getData()[i];
			sum += value;
		}
		return sum;
	}

	
}
